package com.example.hiber.service;

import java.util.List;

import com.example.hiber.entity.FichaEsusCbo;

public interface FichaEsusCboService {
	void add(FichaEsusCbo fichaEsusCbo);
	List<FichaEsusCbo> listAll();
	List<FichaEsusCbo> listAllCriteria();
	List<FichaEsusCbo> filtedQuery();
	List<FichaEsusCbo> filtedQueryCriteria();
	List<FichaEsusCbo> predicateQueryCriteria();
}
