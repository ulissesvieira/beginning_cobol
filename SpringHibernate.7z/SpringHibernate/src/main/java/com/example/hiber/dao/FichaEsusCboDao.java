package com.example.hiber.dao;

import java.util.List;

import com.example.hiber.entity.FichaEsusCbo;

public interface FichaEsusCboDao {
	void add(FichaEsusCbo fichaEsusCbo);
	List<FichaEsusCbo> listAll();
	List<FichaEsusCbo> listAllCriteria();
	List<FichaEsusCbo> filtedQuery();
	List<FichaEsusCbo> filtedQueryCriteria();
	List<FichaEsusCbo> predicateQueryCriteria();
}
