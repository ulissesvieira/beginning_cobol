package com.example.hiber.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.hiber.dao.FichaEsusCboDao;
import com.example.hiber.entity.FichaEsusCbo;

@Service
public class FichaEsusCboServiceImp implements FichaEsusCboService {
	@Autowired
	private FichaEsusCboDao fichaDao;

	@Transactional
	@Override
	public void add(FichaEsusCbo fichaEsusCbo) {
		fichaDao.add(fichaEsusCbo);
	}

	@Transactional(readOnly = true)
	@Override
	public List<FichaEsusCbo> listAll() {		
		return fichaDao.listAll();
	}

	@Override
	public List<FichaEsusCbo> listAllCriteria() {
		return fichaDao.listAllCriteria();
	}

	@Override
	public List<FichaEsusCbo> filtedQuery() {		
		return fichaDao.filtedQuery();
	}

	@Override
	public List<FichaEsusCbo> filtedQueryCriteria() {		
		return fichaDao.filtedQueryCriteria();
	}

	@Override
	public List<FichaEsusCbo> predicateQueryCriteria() {		
		return fichaDao.predicateQueryCriteria();
	}
}
