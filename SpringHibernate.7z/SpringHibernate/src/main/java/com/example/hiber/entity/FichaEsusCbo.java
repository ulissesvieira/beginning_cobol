package com.example.hiber.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "GSH_FICHA_ESUS_CBO")
public class FichaEsusCbo {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ficha_esus_cbo_generator")
	@SequenceGenerator(name = "ficha_esus_cbo_generator", sequenceName="GSH_SEQ_FICHA_ESUS_CBO", allocationSize=20)
	@Column(name = "ID_GSH_FICHA_ESUS_CBO")
	private Integer id;
	
	@Column(name = "FICHA_ESUS")
	private String fichaEsus;
	
	@Column(name = "COD_CBO")
	private String cbo;
	
	public FichaEsusCbo() {}
	
	public FichaEsusCbo(String fichaEsus, String cbo) {
		this.fichaEsus = fichaEsus;
		this.cbo = cbo;
	}
}
