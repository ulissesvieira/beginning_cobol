package com.example.hiber.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.hiber.entity.FichaEsusCbo;

@Repository
public class FichaEsusCboDaoImp implements FichaEsusCboDao {	
	@Autowired
	private EntityManager entityManager;

	@Override
	public void add(FichaEsusCbo fichaEsusCbo) {
		entityManager.persist(fichaEsusCbo);
	}

	@Override
	public List<FichaEsusCbo> listAll() {		
		TypedQuery<FichaEsusCbo> query = entityManager.createQuery("FROM " + FichaEsusCbo.class.getName(), FichaEsusCbo.class);
		
		return query.getResultList();
	}

	@Override
	public List<FichaEsusCbo> listAllCriteria() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FichaEsusCbo> cq = builder.createQuery(FichaEsusCbo.class);
		
		/*Root<FichaEsusCbo> from = cq.from(FichaEsusCbo.class);
		CriteriaQuery<FichaEsusCbo> select = cq.select(from);
		
		TypedQuery<FichaEsusCbo> typedQuery = entityManager.createQuery(select);*/
		
		TypedQuery<FichaEsusCbo> typedQuery = entityManager.createQuery(
				cq.select(cq.from(FichaEsusCbo.class)));
		List<FichaEsusCbo> list = typedQuery.getResultList();
		
		return list;
	}

	@Override
	public List<FichaEsusCbo> filtedQuery() {
		TypedQuery<FichaEsusCbo> typedQuery = entityManager.createQuery(
				"SELECT p FROM " + FichaEsusCbo.class.getName() + " p WHERE p.cbo = :cbo", FichaEsusCbo.class);
		typedQuery.setParameter("cbo", "225112");
		List<FichaEsusCbo> list = typedQuery.getResultList();
		
		return list;
	}

	@Override
	public List<FichaEsusCbo> filtedQueryCriteria() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FichaEsusCbo> cq = builder.createQuery(FichaEsusCbo.class);
		
		Root<FichaEsusCbo> from = cq.from(FichaEsusCbo.class);
		TypedQuery<FichaEsusCbo> typedQuery = entityManager.createQuery(
				cq.select(from).where(builder.equal(from.get("cbo"), "225112")));
		List<FichaEsusCbo> list = typedQuery.getResultList();
		
		return list;
	}

	@Override
	public List<FichaEsusCbo> predicateQueryCriteria() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FichaEsusCbo> cq = builder.createQuery(FichaEsusCbo.class);
		
		Root<FichaEsusCbo> from = cq.from(FichaEsusCbo.class);
		Predicate predicate = builder.and();
		
		predicate = builder.and(predicate, builder.gt(from.get("id"), 100));
		predicate = builder.and(predicate, builder.lt(from.get("id"), 200));
		
		TypedQuery<FichaEsusCbo> typedQuery = entityManager.createQuery(
				cq.select(from).where(predicate)
				.orderBy(builder.asc(from.get(("id")))));
		List<FichaEsusCbo> list = typedQuery.getResultList();
		
		return list;
	}
}
