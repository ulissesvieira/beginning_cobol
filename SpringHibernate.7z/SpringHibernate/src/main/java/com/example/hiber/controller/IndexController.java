package com.example.hiber.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.hiber.entity.FichaEsusCbo;
import com.example.hiber.service.FichaEsusCboService;

@RestController
@RequestMapping(name="/")
public class IndexController {
	@Autowired
	FichaEsusCboService fichaService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String greetings() {
		return "ATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATATA";
	}
	
	@RequestMapping(value="all", method = RequestMethod.GET)
	public List<FichaEsusCbo> getAll() {
		List<FichaEsusCbo> lista = fichaService.listAll();
		return lista;
	}
	
	@RequestMapping(value="criteria/all", method = RequestMethod.GET)
	public List<FichaEsusCbo> getAllCriteria() {
		List<FichaEsusCbo> lista = fichaService.listAllCriteria();
		return lista;
	}
	
	@RequestMapping(value="filted", method = RequestMethod.GET)
	public List<FichaEsusCbo> getFilted() {
		List<FichaEsusCbo> lista = fichaService.filtedQuery();
		return lista;
	}
	
	@RequestMapping(value="criteria/filted", method = RequestMethod.GET)
	public List<FichaEsusCbo> getFiltedCriteria() {
		List<FichaEsusCbo> lista = fichaService.filtedQueryCriteria();
		return lista;
	}
	
	@RequestMapping(value="criteria/predicate", method = RequestMethod.GET)
	public List<FichaEsusCbo> getPredicateCriteria() {
		List<FichaEsusCbo> lista = fichaService.predicateQueryCriteria();
		return lista;
	}
}
