package com.example.hiber.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@PropertySource("classpath:db.properties")
@EnableTransactionManagement
@ComponentScan(basePackages = {
		"com.example.hiber.dao",
		"com.example.hiber.service"                               
})
public class AppConfig {
	@Autowired
	private Environment env;
	
	@Bean
	public DataSource getDataSource() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(env.getProperty("db.driver"));
		dataSource.setUrl(env.getProperty("db.url"));
		dataSource.setUsername(env.getProperty("db.username"));
		dataSource.setPassword(env.getProperty("db.password"));		
		
		return dataSource;
	}
	
//	@Bean
//	public LocalSessionFactoryBean getSessionFactory() {
//		LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
//		factoryBean.setDataSource(getDataSource());
//		
//		Properties props = new Properties();
//		props.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
//		props.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
//		props.put("hibernate.hbm2ddl.jdbc_metadata_extraction_strategy", env.getProperty("hibernate.hbm2ddl.jdbc_metadata_extraction_strategy"));
//		props.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
//		props.put("hibernate.default_schema", env.getProperty("db.username"));
//		
//		factoryBean.setHibernateProperties(props);
//		factoryBean.setPackagesToScan("com.example.hiber.entity");
//		
//		return factoryBean;
//	}
//	
//	@Bean
//	public HibernateTransactionManager getTransactionManager() {
//		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
//		transactionManager.setSessionFactory(getSessionFactory().getObject());
//		
//		return transactionManager;
//	}
	
	@Bean	
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
		emf.setDataSource(getDataSource());
		emf.setJpaVendorAdapter(new HibernateJpaVendorAdapter());		
		emf.setPackagesToScan("com.example.hiber.entity");
		emf.setJpaProperties(getJpaProperties());
		
		return emf;
	}
	
	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager tm = new JpaTransactionManager();
		tm.setEntityManagerFactory(emf);
		
		return tm;
	}
	
	@Bean 
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}
	
	private Properties getJpaProperties() {
		Properties props = new Properties();
		props.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
		props.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
		props.put("hibernate.hbm2ddl.jdbc_metadata_extraction_strategy", env.getProperty("hibernate.hbm2ddl.jdbc_metadata_extraction_strategy"));
		props.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
		props.put("hibernate.default_schema", env.getProperty("db.username"));
		
		return props;
	}
}
